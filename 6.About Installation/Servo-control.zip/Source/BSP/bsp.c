/**
* @par Copyright (C): 2010-2019, Shenzhen Yahboom Tech
* @file         bsp.c
* @author       sax_john
* @version      V1.0
* @date         2015.01.03
* @brief        
* @details      
* @par History  
*                 
* version:	sax_john_20181018
*/

#include "bsp.h"
#include "usart.h"
#include "sys.h"
#include "delay.h"
#include "stdio.h"


extern void NVIC_Configuration(void); 


/**
* Function       bsp_init
* @author        liusen
* @date          2015.01.03    
* @brief         
* @param[in]     void
* @param[out]    void
* @retval        void
* @par History   
*/
void bsp_init(void)
{

	MOTOR_GPIO_Init();  				
	Servo_GPIO_Init();				   
	TIM1_Int_Init(9, 72);				
	Uart1_init(115200);					
	Angle_J1 = 90;						
	delay_init();
	NVIC_Configuration(); 	 
	Start_init();
	
}
